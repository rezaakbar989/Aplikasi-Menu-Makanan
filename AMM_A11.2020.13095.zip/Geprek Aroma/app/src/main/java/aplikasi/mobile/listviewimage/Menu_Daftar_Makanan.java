package aplikasi.mobile.listviewimage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class Menu_Daftar_Makanan extends AppCompatActivity {

    ListView lvItem;
    EditText Edtcari;
    ListViewAdapterCall adapter;
    ArrayList<ListViewAdapterMenu> arraylist = new ArrayList<ListViewAdapterMenu>();

    int[] Gambar;
    String[] NamaItem;
    String[] HargaItem;
    String[] Deskripsi;
    String[] NomorHP;
    String[] Lat;
    String[] Long;

    @Override
    public void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_daftar_makanan);

        lvItem		= (ListView)findViewById(R.id.listView1);
        Edtcari     = (EditText)findViewById(R.id.editText1);


        Gambar		= new int[]{
                R.mipmap.original,
                R.mipmap.sausbbq,
                R.mipmap.sauskeju,
                R.mipmap.sambalijo};

        NamaItem 	= new String[]{
                "Geprek Original",
                "Geprek Saus BBQ",
                "Geprek Saus Keju",
                "Geprek Sambal Ijo"};

        HargaItem 	= new String[]{
                "Rp. 10.000",
                "Rp. 12.000",
                "Rp. 15.000",
                "Rp. 12.000"};

        Deskripsi 	= new String[]{
                "Ayam Geprek Original dengan paduan bumbu yang khas",

                "Dengan Saus BBQ yang menambah kenikmatan hidangan",

                "Dengan Saus Keju yang membuat semakin gurih",

                "Dengan Sambal Ijo yang memiliki citarasa yang khas"};
				

        NomorHP  = new String[]{
                "085643100383",
                "085643100383",
                "085643100383",
                "085643100383",
        };

        Lat  = new String[]{
                "-7.072526326277972",
                "-7.072526326277972",
                "-7.072526326277972",
                "--7.072526326277972"
        };

        Long  = new String[]{
                "110.39131532184179",
                "110.39131532184179",
                "110.39131532184179",
                "110.39131532184179"
        };


        for (int i = 0; i < NamaItem.length; i++)
        {
            ListViewAdapterMenu wp = new ListViewAdapterMenu(NamaItem[i], HargaItem[i], Deskripsi[i], Gambar[i], NomorHP[i], Lat[i], Long[i]);
            arraylist.add(wp);
        }

        adapter = new ListViewAdapterCall(this, arraylist);
        lvItem.setAdapter(adapter);

        Edtcari.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable arg0) {
                String text = Edtcari.getText().toString().toLowerCase(Locale.getDefault());
                adapter.filter(text);
                showToastMessage("Pencarian dilakukan");
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub
            }
            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub
            }
        });

    }

    void showToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
